const minhaDiv = document.getElementById("minha-div")

console.log(minhaDiv)

minhaDiv.innerHTML += "<p>Texto 0</p>"
minhaDiv.innerHTML += "<p>Texto 1</p>"
minhaDiv.innerHTML += "<p>Texto 2</p>"
minhaDiv.innerHTML += "<p>Texto 3</p>"
minhaDiv.innerHTML += "<p>Texto 4</p>"

// for (let i = 0; i < 5; i++) {
//     minhaDiv.innerHTML += `<p>Texto ${i}</p>`
// }