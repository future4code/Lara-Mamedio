function imprimeNome() {
    const meuInput = document.getElementById("meu-input")
    const meuInput2 = document.getElementById("meu-input2")
    console.log(meuInput.value)
    console.log(meuInput2.value)
}

function passouPorCima() {
    console.log("Passou por cima, sai daqui!")
}

function saiuDeCima() {
    console.log("Ufa, tava precisando de um ar!")
}